{"flavor", "0+-", "1-+", "0++", "1--", "0--", "1++", "0-+", "1+-"}
{"light {norm, dim.less}"}
{"strange {norm, dim.less}"}
